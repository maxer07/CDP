package com.epam.oleshchuk.dao;

/**
 * Created with IntelliJ IDEA.
 * User: Maksym_Oleshchuk
 * Date: 28.08.13
 * Time: 13:05
 * To change this template use File | Settings | File Templates.
 */
public interface HelloDao {

    public String createHelloWorld();

}
