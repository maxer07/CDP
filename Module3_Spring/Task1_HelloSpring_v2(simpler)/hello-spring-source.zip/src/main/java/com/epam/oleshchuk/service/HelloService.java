package com.epam.oleshchuk.service;

/**
 * Created with IntelliJ IDEA.
 * User: Maksym_Oleshchuk
 * Date: 28.08.13
 * Time: 12:55
 * To change this template use File | Settings | File Templates.
 */
public interface HelloService {

    public String getHelloWorld();

}
